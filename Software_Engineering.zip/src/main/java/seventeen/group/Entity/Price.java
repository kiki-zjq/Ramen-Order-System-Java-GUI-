package seventeen.group.Entity;

public class Price {
    private Double ramen;
    private Double exNori;
    private Double exEgg;
    private Double exBamboo;
    private Double exChashu;
    private String judgeCode;

    public Double getRamen() {
        return ramen;
    }

    public void setRamen(Double ramen) {
        this.ramen = ramen;
    }

    public Double getExNori() {
        return exNori;
    }

    public void setExNori(Double exNori) {
        this.exNori = exNori;
    }

    public Double getExEgg() {
        return exEgg;
    }

    public void setExEgg(Double exEgg) {
        this.exEgg = exEgg;
    }

    public Double getExBamboo() {
        return exBamboo;
    }

    public void setExBamboo(Double exBamboo) {
        this.exBamboo = exBamboo;
    }

    public Double getExChashu() {
        return exChashu;
    }

    public void setExChashu(Double exChashu) {
        this.exChashu = exChashu;
    }

    public String getJudgeCode() {
        return judgeCode;
    }

    public void setJudgeCode(String judgeCode) {
        this.judgeCode = judgeCode;
    }
}
