package seventeen.group.Entity;

public class Bill {
    private String uid;
    private String soup;
    private String nood;
    private String onion;
    private String nori;
    private String chashu;
    private String boiledEgg;
    private String spiciness;
    private String extraNori;
    private String extraEgg;
    private String bambooShoot;
    private String extraChashu;
    private String ifFree;
    private String price;
    private String payoption;
    private String date;
    private String packet;

    public String getUid() { return uid; }

    public void setUid(String uid) { this.uid = uid; }

    public String getSoup() { return soup; }

    public void setSoup(String soup) {
        this.soup = soup;
    }

    public String getNood() { return nood; }

    public void setNood(String nood) {
        this.nood = nood;
    }

    public String getOnion() {
        return onion;
    }

    public void setOnion(String onion) {
        this.onion = onion;
    }

    public String getNori() { return nori; }

    public void setNori(String nori) {
        this.nori = nori;
    }

    public String getChashu() {
        return chashu;
    }

    public void setChashu(String chashu) {
        this.chashu = chashu;
    }

    public String getBoiledEgg() {
        return boiledEgg;
    }

    public void setBoiledEgg(String boiledEgg) {
        this.boiledEgg = boiledEgg;
    }

    public String getSpiciness() {
        return spiciness;
    }

    public void setSpiciness(String spiciness) {
        this.spiciness = spiciness;
    }

    public String getExtraNori() {
        return extraNori;
    }

    public void setExtraNori(String extraNori) {
        this.extraNori = extraNori;
    }

    public String getExtraEgg() {
        return extraEgg;
    }

    public void setExtraEgg(String extraEgg) {
        this.extraEgg = extraEgg;
    }

    public String getBambooShoot() {
        return bambooShoot;
    }

    public void setBambooShoot(String bambooShoot) {
        this.bambooShoot = bambooShoot;
    }

    public String getExtraChashu() {
        return extraChashu;
    }

    public void setExtraChashu(String extraChashu) {
        this.extraChashu = extraChashu;
    }

    public String getIfFree() {
        return ifFree;
    }

    public void setIfFree(String ifFree) {
        this.ifFree = ifFree;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPayoption() {
        return payoption;
    }

    public void setPayoption(String payoption) {
        this.payoption = payoption;
    }

    public String getDate() { return date; }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPacket() { return packet; }

    public void setPacket(String packet) { this.packet = packet; }
}
