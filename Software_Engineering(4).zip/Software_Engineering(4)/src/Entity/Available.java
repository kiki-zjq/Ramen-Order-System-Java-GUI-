package Entity;

public class Available {
    private String soupTonkotsu;
    private String soupShoyu;
    private String soupShio;
    private String noodleSoft;
    private String noodleMedium;
    private String noodleFirm;
    private String onion;
    private String nori;
    private String chashu;
    private String boiledEgg;
    private String spiciness;
    private String bamboo;
    private String judgeCode;

    public String getSoupTonkotsu() {
        return soupTonkotsu;
    }

    public void setSoupTonkotsu(String soupTonkotsu) {
        this.soupTonkotsu = soupTonkotsu;
    }

    public String getSoupShoyu() {
        return soupShoyu;
    }

    public void setSoupShoyu(String soupShoyu) {
        this.soupShoyu = soupShoyu;
    }

    public String getSoupShio() {
        return soupShio;
    }

    public void setSoupShio(String soupShio) {
        this.soupShio = soupShio;
    }

    public String getNoodleSoft() {
        return noodleSoft;
    }

    public void setNoodleSoft(String noodleSoft) {
        this.noodleSoft = noodleSoft;
    }

    public String getNoodleMedium() {
        return noodleMedium;
    }

    public void setNoodleMedium(String noodleMedium) {
        this.noodleMedium = noodleMedium;
    }

    public String getNoodleFirm() {
        return noodleFirm;
    }

    public void setNoodleFirm(String noodleFirm) {
        this.noodleFirm = noodleFirm;
    }

    public String getOnion() {
        return onion;
    }

    public void setOnion(String onion) {
        this.onion = onion;
    }

    public String getNori() { return nori; }

    public void setNori(String nori) {
        this.nori = nori;
    }

    public String getChashu() {
        return chashu;
    }

    public void setChashu(String chashu) {
        this.chashu = chashu;
    }

    public String getBoiledEgg() {
        return boiledEgg;
    }

    public void setBoiledEgg(String boiledEgg) {
        this.boiledEgg = boiledEgg;
    }

    public String getSpiciness() {
        return spiciness;
    }

    public void setSpiciness(String spiciness) {
        this.spiciness = spiciness;
    }

    public String getBamboo() { return bamboo; }

    public void setBamboo(String bamboo) {
        this.bamboo = bamboo;
    }

    public String getJudgeCode() {
        return judgeCode;
    }

    public void setJudgeCode(String judgeCode) {
        this.judgeCode = judgeCode;
    }
}
